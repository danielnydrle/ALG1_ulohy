/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mikenda;

/**
 *
 * @author petrm
 */
import java.util.Arrays;

public class EratosthenovoSito {
    public static void main(String[] args) {
        boolean[] a = create(10);
        for (int i = 0; i < a.length; i++) {
            System.out.format("%d:%b " ,i, a[i]);
        }
    }
    /**
     * Vytvoří pole typu boolean velikosti size, vyplní jej s true hodntou, poté změní každý prvek na false, zda se nejedná o prvočílo - řešeno Eratosthenovým sítem
     * @param size
     * @return 
     */
    public static boolean[] create(int size) {
        boolean[] a = new boolean[size];
        Arrays.fill(a, true);
        if (a.length >= 1) a[0] = false;
        if (a.length >= 2) a[1] = false;
        for (int i = 2; i < size; i++) {
            if (a[i] == true) {
                if (jePrvocislo(i)) {
                    for (int j = 2; j < (a.length / i)+1; j++) {
                        if (i*j == a.length) continue;
                        a[i * j] = false;
                    } 
                }                
            } 
        }
        return a;
    }
    /**
     * Zjistí zda číslo a je prvočíslo - vrací hodnotu true/false
     * @param a
     * @return 
     */
    public static boolean jePrvocislo(int a) {
        int i, m = 0, flag = 0;
        m = a / 2;
        if (a == 0 || a == 1) return false;
        else {
            for (i = 2; i <= m; i++) {
                if (a % i == 0) {
                    flag = 1;
                    return false;
                }
            }
            if (flag == 0) return true;
        }
        return true;
    }
    
}

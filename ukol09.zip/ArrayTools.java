package mikenda;

/**
 *
 * @author petrm
 */
import java.util.Arrays;
public class ArrayTools {
    public static void main(String[] args) {
        int b[] = new int[7];
        b[0] = -1;
        b[1] = 2;
        b[2] = -3;
        b[3] = 4;
        b[4] = -5;
        b[5] = 5;       
        b[6] = -6;
        System.out.println("Pole: " + Arrays.toString(b));               
        System.out.println("Soucet: " + soucet(b));        
        System.out.println("Soucet: " + soucet(b, 3));
        System.out.println("Max: " + max(b, 7));
        System.out.println("Prvni pozice max: " + prvniPoziceMaxima(b));
        System.out.println("Posledni pozice max: " + posledniPoziceMaxima(b));
        System.out.println("Pocet vyskytu: " + pocetVyskytu(b, 7, 5));
        System.out.println("Vzestupnost: " + jeVzestupneUsporadana(b, 7));
        System.out.println("Stridavost: " + jeStridavaPosloupnost(b));
        System.out.print("Řazení: ");
        selectSort(b, 0, 6);
        reverse(b);
        System.out.println("Obrácené pole: " + Arrays.toString(b));
        int[] reversed = getReversed(b);
        System.out.println("Obrácené pole: " + Arrays.toString(reversed));


    }
    /**
     * Sečte všechny prvky pole a
     * @param a
     * @return 
     */
    public static int soucet(int[] a) {
        int soucet = 0;
        for (int x : a) {
            soucet += x;
        }
        return soucet;
    }
    /**
     * Sečte všechny prvky pole a do indexu n
     * @param a
     * @param n
     * @return 
     */
    public static int soucet(int[] a, int n) {
        int soucet = 0;
        for (int i = 0; i < n; i++) {
            soucet += a[i];
        }
        return soucet;
    }
    /**
     * Najde maximální hodnotu v poli a do indexu n
     * @param a
     * @param n
     * @return 
     */
    public static int max(int[] a, int n) {
        int max = a[0];
        for (int i = 1; i < n; i++) {
            if (a[i] > max) {
                max = a[i];
            }
        }
        return max;
    }
    /**
     * Najde první výskyt maxima v poli a
     * @param a
     * @return 
     */
    public static int prvniPoziceMaxima(int[] a) {
        int max = a[0];
        int prvniPozice = 0;
        for (int i = 1; i < a.length; i++) {
            if (a[i] > a[prvniPozice]) {
                prvniPozice = i;
            }
        }
        return prvniPozice;
    }
    /**
     * Najde poslední výskyt maxima v poli a
     * @param a
     * @return 
     */
    public static int posledniPoziceMaxima(int[] a) {
        int posledniPozice = 0;
        for (int i = a.length - 1; i >= 0; i--) {
            if (a[i] > a[posledniPozice]) {
                posledniPozice = i;
            }
        }
        return posledniPozice;

    }
    /**
     * Najde pocet vyskytu cislo v poli a do indexu n
     * @param a
     * @param n
     * @param cislo
     * @return 
     */
    public static int pocetVyskytu(int[] a, int n, int cislo) {
        int pocetVyskytu = 0;
        for (int i = 0; i < n; i++) {
            if (cislo == a[i]) {
                pocetVyskytu++;
            }
        }
        return pocetVyskytu;
    }
    /**
     * Zjistí. zda je pole a do indexu n vzestupně uspořádáno (vrací true/false)
     * @param a
     * @param n
     * @return 
     */
    public static boolean jeVzestupneUsporadana(int[] a, int n) {
        int temp = a[0];
        for (int i = 1; i < n; i++) {
            if (temp > a[i]) {
                return false;
            }
            temp = a[i];
        }
        return true;
    }
    /**
     * Zjistí, zda je pole a střídává posloupnost (prvky střídají + -) (vrací true/false)
     * @param a
     * @return 
     */
    public static boolean jeStridavaPosloupnost(int[] a) {

        for (int i = 0; i < a.length - 2; i++) {
            if (a[i] * a[i + 1] > 0) {
                return false;
            }
        }
        return true;
    }
    /**
     * Seřadí vzestupně pole a pomocí Selection sortu, od indexu d (včetně) do indexu h (vyjma) 
     * @param a
     * @param d
     * @param h 
     */
    public static void selectSort(int[] a, int d, int h) {
        for (int i = d; i < h; i++) {
            int minIndex = i;
            for (int j = i + 1; j < h; j++) {
                if (a[j] < a[minIndex]) {
                    minIndex = j;
                }
            }
            int min = a[minIndex];
            a[minIndex] = a[i];
            a[i] = min;
        }
        System.out.println(Arrays.toString(a));
    }
    /**
     * Obrátí existující pole a
     * @param a 
     */
    public static void reverse(int[] a) {
        int delka  = a.length%2 == 1 ? a.length/2 +1 : a.length/2;
        for (int i = 0; i < delka; i++) {
            if (a.length % 2 == 1 && i == (a.length/2 + 1)) {
                continue;
            }
            int temp = a[a.length - i - 1];
            a[a.length - i - 1] = a[i];
            a[i] = temp;
        }
    }
    /**
     * Vrátí nové pole rev, které je obrácené pole a
     * @param a
     * @return 
     */
    public static int[] getReversed(int[] a) {
        int[] rev = new int[a.length];
//        for (int i = 0; i < a.length / 2; i++) {
//            int temp = a[a.length - i - 1];
//            rev[a.length - i - 1] = a[i];
//            rev[i] = temp;
//        }
//        
//       
        int delka  = rev.length%2 == 1 ? rev.length/2 +1 : rev.length/2;
        for (int i = 0; i < delka; i++) {
            if (rev.length % 2 == 1 && i == (rev.length/2 + 1)) {
                continue;
            }
            int temp = a[rev.length - i - 1];
            rev[rev.length - i - 1] = a[i];
            rev[i] = temp;
        } 
        return rev;
    }

}

//Poslední pozice maxima - postačilo by porovnávat pomocí >= nebo procházet odzadu. - opraveno
//Střídavá posloupnost - co takhle využít vlastnost součinu. Opravit. - opraveno
//SelectSort není “Select sort”. Nutno opravit. - opraveno
//getReversed() je chybně. Nutno opravit. - opraveno

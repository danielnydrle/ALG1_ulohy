/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mikenda;

/**
 *
 * @author petrm
 */
import mikenda.MatrixTools;

public class MatrixToolsTest {
    public static void main(String[] args) {
        int[][] a = {
                        {0, 2, 3, 14, 0},
                        {5, 16, 7, 0, 14},
                        {15, 9, 0, 7, 3},
                        {10, 0, 9, 16, 2},
                        {0, 10, 15, 5, 0}
        };
        int[][] b = {{11, 3, 0, 3, 11},
                        {12, 1, 1, 13, 12},
                        {1, 2, 3, 4, 8},
                        {12, 1, 1, 13, 12},
                        {11, 3, 0, 3, 11}
        };
        int[][] c = {{11, 3, 0, 3, 11},
                        {12, 1, 1, 1, 12},
                        {7, 0, 2, 0, 7},
                        {1, 5, 3, 5, 1}
        };
        double[][] d = {{0, -2, -3, 14, 0},
                        {5, 6, 7, 0, 14},
                        {-15, 9, 5, 7, -3},
                        {10, 0, 9, 6, -2},
                        {0, 10, -15, 5, 0}
        };
        double[][] e = {{0, 2, 3, 14, 0},
                        {5, 6, 7, 0, 14},
                        {15, 9, 5, 7, -3},
                        {10, 0, 9, 6, -2},
                        {0, 10, -15, 5, 0}
        };
        System.out.println("Matice A:");
        System.out.println("Symetrická dle antidiagonály: " + MatrixTools.jeSymDleDiag2(a));
        System.out.println("Symetrická dle prostřední řádky: " + MatrixTools.jeSymDleHoriz(a));
        System.out.println("Symetrická dle prostřední řádky: " + MatrixTools.jeSymDleVert(a));
        
        System.out.println("\nMatice B:");
        System.out.println("Symetrická dle antidiagonály: " + MatrixTools.jeSymDleDiag2(b));
        System.out.println("Symetrická dle prostřední řádky: " + MatrixTools.jeSymDleHoriz(b));
        System.out.println("Symetrická dle prostřední řádky: " + MatrixTools.jeSymDleVert(b));
        
        System.out.println("\nMatice C:");
        System.out.println("Symetrická dle antidiagonály: " + MatrixTools.jeSymDleDiag2(c));
        System.out.println("Symetrická dle prostřední řádky: " + MatrixTools.jeSymDleHoriz(c));
        System.out.println("Symetrická dle prostřední řádky: " + MatrixTools.jeSymDleVert(c));
        
        System.out.println("\nSymetrie dle antidigonály (matice s reálnýmmi čísly:)");
        System.out.println("Matice d: " + MatrixTools.jeSymetricka(d, 1E-7));
        System.out.println("Matice e: " + MatrixTools.jeSymetricka(e, 1E-7));
        
    }

}

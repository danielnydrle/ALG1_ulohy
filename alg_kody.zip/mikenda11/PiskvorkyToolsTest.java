/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mikenda;

import mikenda.PiskvorkyTools;

/**
 *
 * @author petrm
 */
public class PiskvorkyToolsTest {

    private static int[][] testMat
            = {
                {1, 1, 1, 1, 7, 3},
                {1, 0, 1, 1, 7, 3},
                {5, 5, 0, 1, 7, 7},
                {1, 5, 1, 0, 7, 0},
                {1, 1, 5, 1, 0, 1}
            };
    /**
     * Vypíše matici po řádcích
     * @param a matice
     * @param titulek popisek matice
     */
    private static void vypisMatici(int[][] a, String titulek) {
        System.out.println();
        System.out.println(titulek);
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[0].length; j++) {
                System.out.print(a[i][j] + " ");
                if (j == a[0].length - 1) {
                    System.out.println("");
                }
            }
        }
    }

    public static void main(String[] args) {

        vypisMatici(testMat, "Vstupni matice - testovaci data");

        
        int[][] pocty = new int[testMat.length][testMat[0].length];
        // test metody pocetStejnychVRadce()
        for (int i = 0; i < pocty.length; i++) {
            for (int j = 0; j < pocty[i].length; j++) {
                
                pocty[i][j] = PiskvorkyTools.pocetStejnychVRadce(testMat, i, j);
            }
        }
        vypisMatici(pocty, "Matice s daty poctu stejnych v radce");
        
        // test metody pocetStejnychVSloupci()
        for (int i = 0; i < pocty.length; i++) {
            for (int j = 0; j < pocty[i].length; j++) {                
                pocty[i][j] = PiskvorkyTools.pocetStejnychVSloupci(testMat, i, j);
            }
        }       
        vypisMatici(pocty, "Matice s daty poctu stejnych ve sloupci");
        
        // test metody pocetStejnychVDiag1()
        for (int i = 0; i < pocty.length; i++) {
            for (int j = 0; j < pocty[i].length; j++) {
                pocty[i][j] = PiskvorkyTools.pocetStejnychVDiag1(testMat, i, j);
            }
        }
        vypisMatici(pocty, "Matice s daty poctu stejnych ve směru diagonaly");
        
        // test metody pocetStejnychVDiag2()
        for (int i = 0; i < pocty.length; i++) {
            for (int j = 0; j < pocty[i].length; j++) {                
                pocty[i][j] = PiskvorkyTools.pocetStejnychVDiag2(testMat, i, j);
            }
        }
        vypisMatici(pocty, "Matice s daty poctu stejnych ve směru antidiagonaly");
    }
}

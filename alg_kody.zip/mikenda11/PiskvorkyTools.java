/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mikenda;

/**
 *
 * @author petrm
 */
public final class PiskvorkyTools {
    /**
     * Zjistí zda se v nějaké řádce matice vysktuje řada čísla (vedle sebe),
     * které je na indexu r,s
     *
     * @param a matice
     * @param r index řádku
     * @param s index sloupce
     * @return pocet čísel(1 a vyšší), pokud je matice chybně zapsána vrací
     * hodnotu 0
     */
    public static int pocetStejnychVRadce(int[][] a, int r, int s) {
        if (overeni(a,r,s) == 1) {
            int pocet = 1;
            int smer = -1;
            int konec = 1;
            for (int i = 0, j = s; i < a[0].length; i++) {
                if (j == 0) {
                    break;
                }
                
                if (a[r][s] == a[r][j + smer]) {
                    pocet++;
                } else {
                    break;
                }
                j += smer;
            }
            smer = 1;
            for (int i = 0, j = s; i < a[0].length; i++) {
                if (j >= a[0].length-1) {
                    break;
                }
                
                if (a[r][s] == a[r][j + smer]) {
                    
                    pocet++;
                } else {
                    break;
                }
                j += smer;
            }
            return pocet;
        } else {
            return 0;
        }

    }

    /**
     * Zjistí zda se v nějakém sloupci matice vysktuje řada čísla (pod sebou),
     * které je na indexu r,s
     *
     * @param a matice
     * @param r index řádku
     * @param s index sloupce
     * @return pocet čísel(1 a vyšší), pokud je matice chybně zapsána vrací
     * hodnotu 0
     */
    public static int pocetStejnychVSloupci(int[][] a, int r, int s) {
        if (overeni(a,r,s) != 0) {
            int pocet = 1;
            int smer = -1;
            for (int i = 0, j = r; i < a.length; i++) {
                if (j == 0) {
                    break;
                }
                
                if (a[r][s] == a[j+smer][s]) {
                    pocet++;
                } else {
                    break;
                }
                j += smer;
            }
            smer = 1;
            for (int i = 0, j = r; i < a.length; i++) {
                if (j >= a.length - 1) {
                    break;
                }
                
                if (a[r][s] == a[j+smer][s]) {
                    pocet++;
                } else {
                    break;
                }
                j += smer;
            }
            return pocet;
        } else {
            return 0;
        }

    }

    /**
     * Zjistí zda se ve směru diagonály matice vysktuje řada čísla (šikmo dolu),
     * které je na indexu r,s
     *
     * @param a matice
     * @param r index řádku
     * @param s index sloupce
     * @return pocet čísel(1 a vyšší), pokud je matice chybně zapsána vrací
     * hodnotu 0
     */
    public static int pocetStejnychVDiag1(int[][] a, int r, int s) {
        if (overeni(a,r,s) == 1) {
            int pocet = 1;
            int smer = -1;
            for (int i = 0, j = r, k = s; i < a.length; i++) {
                if (j == 0 || k == 0) {
                    break;
                }
                
                if (a[r][s] == a[j+smer][k+smer]) {
                    pocet++;
                } else {
                    break;
                }
                j += smer;
                k += smer;
            }
            smer = 1;
            for (int i = 0, j = r, k = s; i < a.length; i++) {
                if (j >= a.length - 1 || k >= a[0].length - 1) {
                    break;
                }
                
                if (a[r][s] == a[j+smer][k+smer]) {
                    pocet++;
                } else {
                    break;
                }
                j += smer;
                k += smer;
            }
            return pocet;
        } else {
            return 0;
        }

    }

    /**
     * Zjistí zda se ve směru antidiagonály matice vysktuje řada čísla (šikmo
     * nahoru), které je na indexu r,s
     *
     * @param a matice
     * @param r index řádku
     * @param s index sloupce
     * @return pocet čísel(1 a vyšší), pokud je matice chybně zapsána vrací
     * hodnotu 0
     */
    public static int pocetStejnychVDiag2(int[][] a, int r, int s) {
        if (overeni(a,r,s) != 0) {
            int pocet = 1;
            int smer = -1;
            for (int i = 0, j = r, k = s; i < a.length; i++) {
                if (j >= a.length - 1 || k == 0) {
                    break;
                }
                
                if (a[r][s] == a[j-smer][k+smer]) {
                    pocet++;
                } else {
                    break;
                }
                j -= smer;
                k += smer;
            }
            smer = 1;
            for (int i = 0, j = r, k = s; i < a.length; i++) {
                if (k >= a[0].length - 1 || j == 0) {
                    break;
                }
                
                if (a[r][s] == a[j-smer][k+smer]) {
                    pocet++;
                } else {
                    break;
                }
                j -= smer;
                k += smer;
            }
            return pocet;
        } else {
            return 0;
        }

    }

    /**
     * Zjistí zda není matice a prázdná, nebo zda nejsou zadané indexy mimo matici
     * @param a
     * @return 1 -> pokud jsou parametry a matice v pořádku 0 -> pokud je prazdná, nebo pokud jsou špatné indexy
     */
    public static int overeni(int[][] a, int r, int s) {
        if (a == null) {
            return 0;
        }

        if (a.length == 0) {
            return 0;
        }

        if (a[0].length == 0) {
            return 0;
        }
        if (r >= a.length) {
            return 0;
        }
        if (s >= a[0].length) {
            return 0;
        }
        
        return 1;
    }

}

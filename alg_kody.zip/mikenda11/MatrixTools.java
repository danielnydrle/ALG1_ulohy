/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mikenda;

/**
 *
 * @author petrm
 */
import java.util.Arrays;

public final class MatrixTools {
    /**
     * Zjistí zda je čtvercová matice a symetrická dle antidiagonály
     * Jsou zde dvě možnosti, zakomentovaná obrátí v matici sloupce a poté je testuje jako symetri podle diagonály.
     * Druhá možnost (nezakomentovaná) testuje originální matici (na první pohled není jasné jak přesně funguje)
     * @param a matice
     * @return Pokud je symterická -> true, pokud ne -> false
     */
    public static boolean jeSymDleDiag2(int[][] a) {
        int radky = a.length-1;
        int sloupce = a[0].length-1;
        for (int i = 0; i < a.length-1; i++) {
            for (int j = 0; j < a[0].length-i; j++) {
                if (a[i][j] != a[radky][sloupce]) {
                    return false;
                }
                if (j + i == a.length-2) {
                    sloupce--;
                    radky = a.length-1;
                    break;
                }
                radky--;
            }
        }
        return true;
    }
    /**
     * Testuje zda je matice a symetrická dle prostřední řádky
     * @param a matice
     * @return Pokud je symterická -> true, pokud ne -> false
     */
    public static boolean jeSymDleHoriz(int[][] a) {
        for (int i = 0; i < a[0].length; i++) {
            for (int j = 0, k = a.length-1; j < a.length/2; j++, k--) {
                if (a[j][i] != a[k][i]) {
                    return false;
                }
            }
        }
        return true;
    }
    /**
     * Testuje, zda je matice symetrická dle prostředního sloupce
     * @param a matice
     * @return Pokud je symterická -> true, pokud ne -> false
     */
    public static boolean jeSymDleVert(int[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0, k = a[0].length - 1; j < a[0].length / 2; j++, k--) {
                if (a[i][j] != a[i][k]) {
                    return false;
                }
            }
        }
        return true;
    }
    /**
     * Testuje zda je matice a symetrická dle antidiagonály, matice obsahuje reálná čísla -> provnáváme rozdíl dvou prvků matice s epsFaktorem vynásobeným absolutním maximem matice 
     * @param a matice
     * @param epsFaktor velmi malé reálné číslo (1E-7, 1E-12 ...)
     * @return Pokud je symterická -> true, pokud ne -> false
     */
    public static boolean jeSymetricka(double[][] a, double epsFaktor) {
        int radky = a.length-1;
        int sloupce = a[0].length-1;
        double EPS = epsFaktor * absMax(a);
        for (int i = 0; i < a.length-1; i++) {
            for (int j = 0; j < a[0].length-i; j++) {
                if (Math.abs(a[i][j] - a[radky][sloupce]) >= EPS) {
                    return false;
                }
                if (j + i == a.length-2) {
                    //radky++;
                    sloupce--;
                    radky = a.length-1;
                    break;
                }
                radky--;
            }
        }
        return true;
    }
    /**
     * Vrátí absolutní hodnotu maxima matice a
     * @param a matice
     * @return absolutní maximum matice
     */
    public static double absMax(double[][] a) {
        double absMax = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[0].length; j++) {
                if (absMax < Math.abs(a[i][j])) {
                    absMax = Math.abs(a[i][j]);
                }
            }
        }
        return absMax;
    }

}

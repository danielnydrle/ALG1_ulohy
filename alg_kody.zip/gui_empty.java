/*
 * Copyright (C) 2022 Jirina Kralovcova
 * This program is part of Java programing education. 
 * You can use it as you need to learn Java. 
 */

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author 
 */
public class MatrixOperation {

    private static final Scanner sc = new Scanner(System.in);
    private static double[][] matA = null;
    private static double[][] matB = null;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        boolean konecProgramu;
        do {
            vypisMenu();
            int volba = nactiVolbu();
            konecProgramu = obsluzVolbu(volba);
        } while (!konecProgramu);
        System.out.println("Koncim ...");
    }

    private static void vypisMenu() {
        System.out.println("");
        System.out.println("Hlavni menu programu");
        System.out.println("1. Zadat matici A");
        System.out.println("2. Zadat matici B");
        System.out.println("3. Vypsat obe matice");
        System.out.println("4. Vzajemna vymena matic");
        System.out.println("5. Soucet matic");
        System.out.println("6. Soucin matic");
        System.out.println("7. Konverze prvni matice do normovaneho tvaru");
        System.out.println("8. Test, zda prvni matice je stochaticka ");
        System.out.println("0. Konec programu");
    }

    private static int nactiVolbu() {
        System.out.print("zadej volbu: ");
        int volba;
        try {
            volba = sc.nextInt();
        } catch (InputMismatchException ex) {
            volba = -1;
        }
        sc.nextLine();
        return volba;
    }

    private static boolean obsluzVolbu(int volba) {
        switch (volba) {
            case 0:
                return true;
            case 1:
                matA = nactiMatici();
                break;
            case 2:
                break;
            case 3:
                vypisObouMatic();
                break;
            case 4:
                vymenaMatic();
                break;
            case 5:
                soucetMaticVypis();
                break;
            case 6:
                soucinMaticVypis();
                break;
			case 7:
                
                break;
			case 8:
                
                break;
            default:
                System.out.println("Neznama volba");
        }
        return false;
    }
	
	private static void vypisObouMatic() {
        // zajistit vypis kazde z matic s vhodnym titulkem, 
		// popripade vypsat informaci, ze nebyla zatim nactena
    }

    private static void vypisMatice(double[][] a, String titulek) {
        System.out.println("");
        System.out.println(titulek);
        // doplnit
    }

    private static double[][] nacteniMatice() {
        System.out.println("Zadej pocet radku");
        int pr = sc.nextInt();
        System.out.println("Zadej pocet sloupcu");
        int ps = sc.nextInt();
        // doplnit dle 
        return a;
    }

    private static void vymenaMatic() {
        System.out.println("");
        System.out.println("Vzajemna vymena matic");
		// postaci vymenit reference
    }

    private static void soucetMaticVypis() {
        System.out.println("");
        System.out.println("Soucet matic");
    }

    private static void soucinMaticVypis() {
        System.out.println("");
        System.out.println("Soucin matic");
    }


	
	// vsechny dalsi metody dle potreb realizace zadani

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mikenda;

/**
 *
 * @author petrm
 */
import java.util.Arrays;
import java.util.Random;

public class PexesoTools {

//    public static void main(String[] args) {
//        System.out.print(Arrays.deepToString(vytvorRozlozenePexeso(5,3 )));
//        System.out.print(testMaticePexeso(vytvorRozlozenePexeso(5,3), 7));
//        
//    }

    /**
     * Vytvoří matici o rozměrech pr×ps. Vyplní je dvojicemi od 1 do pr*ps (náhodně zamíchaných)
     *
     * @param pr počet řádků
     * @param ps počet sloupců
     * @return matice s dvojicemi
     */
    public static int[][] vytvorRozlozeniPexeso(int pr, int ps) {
        int[][] pexeso = new int[pr][ps];
        int policko = 1;
        int temp = 0;
        int pd = pr * ps / 2;

        Random rnd = new Random();
        int rndNumR = rnd.nextInt(pr);
        int rndNumS = rnd.nextInt(ps);

        for (int i = 0; i < pexeso.length; i++) {
            int rndNum = rnd.nextInt(pd);
            for (int j = 0; j < pexeso[0].length; j++) {
                pexeso[i][j] = policko;
                policko++;
                if (pr * ps / 2 < policko) {
                    policko = 1;
                }
            }
        }
        if (pr * ps % 2 == 1) {
            pexeso[pr - 1][ps - 1] = 0;
        }

        for (int i = 0; i < pr; i++) {
            for (int j = 0; j < ps; j++) {
                temp = pexeso[rndNumR][rndNumS];
                pexeso[rndNumR][rndNumS] = pexeso[i][j];
                pexeso[i][j] = temp;
                rndNumR = rnd.nextInt(pr);
                rndNumS = rnd.nextInt(ps);
            }
        }
        return pexeso;
    }

    /**
     * Zjistí zda matice a obsahuje dvojice čísel od 1 až po pd
     *
     * @param a
     * @param pd
     * @return true/false
     */
    public static boolean testMaticePexeso(int[][] a, int pd) {
        int zacatekSloupec = ((a[0].length * a.length) / 2) % a[0].length;
        int zacatekRadek = a.length / 2;
        int[] pexeso = new int[pd*2];
        Arrays.fill(pexeso,-1);
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[0].length; j++) {
                int temp = a[i][j];
                if (a[i][j] == 0) {
                    continue;
                }
                if (pexeso[a[i][j]-1] != -1) {
                    pexeso[a[i][j] + pd - 1] = a[i][j];
                }
                else {
                    pexeso[a[i][j]-1] = a[i][j];
                }
            }
        }

        for (int i = 0; i < pd; i++) {
            if (pexeso[i] != pexeso[i+pd]) {
                return false;
            }
        }
        return true;
    }

    /**
     * Vytvoří pole s dvojicemi čísel od 1 do pocetDvojic (náhodně zamíchanýh)
     *
     * @param pocetDvojic (čísla od 1 ... pocetDvojic)
     * @return pole s dvojicemi
     */
    public static int[] vytvorRozlozeniPexeso(int pocetDvojic) {
        int[] pexeso = new int[pocetDvojic * 2];
        int temp = 0;

        Random rnd = new Random();
        int rndNum = rnd.nextInt(pocetDvojic);

        for (int i = 0; i < pocetDvojic; i++) {
            pexeso[i] = i + 1;
            pexeso[i + pocetDvojic] = i + 1;
        }

        for (int i = 0; i < pocetDvojic * 2; i++) {
            temp = pexeso[rndNum];
            pexeso[rndNum] = pexeso[i];
            pexeso[i] = temp;
            rndNum = rnd.nextInt(pocetDvojic);
        }

        return pexeso;
    }

}

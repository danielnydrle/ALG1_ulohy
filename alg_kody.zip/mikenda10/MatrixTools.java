/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mikenda;

/**
 *
 * @author petrm
 */
import java.util.Arrays;

public class MatrixTools {
    /**
     * Sečte prvek matice a s prvkem matice b - vrátí matici s těmito součty
     *
     * @param a
     * @param b
     * @return
     */
    private static double EPS = 1E-7;
    public static double[][] soucetMatic(double[][] a, double[][] b) {
        if (a == null) {
            return null;
        }
        if (b == null) {
            return null;
        }
        if (a.length == 0) {
            return null;
        }
        if (b.length == 0) {
            return null;
        }
        if (a.length != b.length) {
            return null;
        }
        if (a[0].length == 0) {
            return null;
        }
        if (b[0].length == 0) {
            return null;
        }
        if (a[0].length != b[0].length) {
            return null;
        }

        double[][] soucet = new double[a.length][a[0].length];
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[0].length; j++) {
                soucet[i][j] = a[i][j] + b[i][j];
            }
        }

        return soucet;
    }

    /**
     * Vynásobí prvek matice a s prvkem matice b - vrátí matici s těmito součiny
     *
     * @param a
     * @param b
     * @return
     */
    public static double[][] soucinMatic(double[][] a, double[][] b) {
        if (a == null) {
            return null;
        }
        if (b == null) {
            return null;
        }
        if (a.length == 0) {
            return null;
        }
        if (b.length == 0) {
            return null;
        }
        if (a.length != b.length) {
            return null;
        }
        if (a[0].length == 0) {
            return null;
        }
        if (b[0].length == 0) {
            return null;
        }
        if (a[0].length != b[0].length) {
            return null;
        }
        double[][] soucin = new double[a.length][a[0].length];
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a.length; j++) {
                
                for (int k = 0; k < a.length; k++) {
                    soucin[i][j] += a[i][k] * b[k][j];
                }  
                  
            }  
                
        }
        return soucin;
    }

    /**
     * Vytvoří jednotkovou matici o výšce n a šířce n
     *
     * @param n
     * @return
     */
    public static double[][] jednotkovaMatice(int n) {
        double[][] jednMat = new double[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (j == i) {
                    jednMat[i][j] = 1;
                } else {
                    jednMat[i][j] = 0;
                }
            }
        }
        return jednMat;
    }

    /**
     * Převde matice a do normovaného stavu (vydělí každý prvek maximální
     * absolutní hodntou matice)
     *
     * @param a
     */
    public static void prevedDoNorm(double[][] a) {
        double absMax = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[0].length; j++) {
                if (absMax < Math.abs(a[i][j])) {
                    absMax = Math.abs(a[i][j]);
                }
            }
        }
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[0].length; j++) {
                a[i][j] = a[i][j] / absMax;
            }
        }        
    }

    /**
     * Zjistí zda je matice a stochaticka (obsahuje pouze nezaporna čísla, a
     * součet každého řádku je roven 1)
     *
     * @param a
     * @return
     */
    public static boolean jeStochaticka(double[][] a) {
        double radSoucet = 0;
        
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[0].length; j++) {
                if (a[i][j] < 0) {
                    return false;
                }
                radSoucet += a[i][j];

            }
            if (Math.abs(radSoucet - 1) >= EPS) {
                return false;
            }
            radSoucet = 0;
        }
        
        return true;
    }

}

//MatrixTools - test stochatické matice - při porovnání součtu je nutno pamatovat na to, že součet je reálné číslo.


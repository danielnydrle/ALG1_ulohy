package mikenda;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
import java.util.Arrays;
import mikenda.PexesoTools;
/**
 *
 * @author petrm
 */
public class PexesoToolsTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[][] pexeso = PexesoTools.vytvorRozlozeniPexeso(8,12);
        System.out.println(Arrays.deepToString(pexeso));
        jePexeso(pexeso, 8*12);
        int [] pexesoArr = PexesoTools.vytvorRozlozeniPexeso(5);
        System.out.println(Arrays.toString(pexesoArr));
    }
    
    public static void jePexeso(int[][] a, int pd) {
        if (PexesoTools.testMaticePexeso(a, pd)) {
            System.out.println("Matice je pexeso");
        } else {
            System.out.println("Matice není pexeso");
        }
               
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mikenda;

import java.util.InputMismatchException;
import java.util.Scanner;
import mikenda.MatrixTools;

/**
 *
 * @author petrm
 */
public class MatrixOperation {

    private static final Scanner sc = new Scanner(System.in);
    private static double[][] matA = null;
    private static double[][] matB = null;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        boolean konecProgramu;
        do {
            vypisMenu();
            int volba = nactiVolbu();
            konecProgramu = obsluzVolbu(volba);
        } while (!konecProgramu);
        System.out.println("Koncim ...");
    }

    /**
     * Vypíše do konzole nabídku možností
     */
    private static void vypisMenu() {
        System.out.println("");
        System.out.println("Hlavni menu programu");
        System.out.println("1. Zadat matici A");
        System.out.println("2. Zadat matici B");
        System.out.println("3. Vypsat obe matice");
        System.out.println("4. Vzajemna vymena matic");
        System.out.println("5. Soucet matic");
        System.out.println("6. Soucin matic");
        System.out.println("7. Konverze prvni matice do normovaneho tvaru");
        System.out.println("8. Test, zda prvni matice je stochaticka ");
        System.out.println("0. Konec programu");
    }

    /**
     * Načte volbu (číslo) od uživatele
     *
     * @return
     */
    private static int nactiVolbu() {
        System.out.print("zadej volbu: ");
        int volba;
        try {
            volba = sc.nextInt();
        } catch (InputMismatchException ex) {
            volba = -1;
        }
        sc.nextLine();
        return volba;
    }

    /**
     * Zvolí podle zadaného čísla (volba) jaká metoda se bude používat jako
     * nalsedující
     *
     * @param volba
     * @return true/false
     */
    private static boolean obsluzVolbu(int volba) {
        switch (volba) {
            case 0:
                return true;
            case 1:
                matA = nacteniMatice();
                break;
            case 2:
                matB = nacteniMatice();
                break;
            case 3:
                vypisObouMatic();
                break;
            case 4:
                vymenaMatic();
                break;
            case 5:
                soucetMaticVypis();
                break;
            case 6:
                soucinMaticVypis();
                break;
            case 7:
                prevedDoNormVypis();
                break;
            case 8:
                jeStochatickaVypis();
                break;
            default:
                System.out.println("Neznama volba");
        }
        return false;
    }

    /**
     * Vypíše obě matice, popřípadě napíše, že nejsou načteny
     */
    private static void vypisObouMatic() {
        // zajistit vypis kazde z matic s vhodnym titulkem, 
        // popripade vypsat informaci, ze nebyla zatim nactena
        if (jeNactena(matA)) {
            System.out.println("");
            vypisMatice(matA, "Matice A");
        } else {
            System.out.println("");
            System.out.println("Matice A není načtena");
        }
        if (jeNactena(matB)) {
            System.out.println("");
            vypisMatice(matB, "Matice B");
        } else {
            System.out.println("");
            System.out.println("Matice B není načtena");
        }
    }

    /**
     * Vypíše do konzole matici a s titulkem
     *
     * @param a matice
     * @param titulek string s popisem matice
     */
    private static void vypisMatice(double[][] a, String titulek) {
        System.out.println("");
        System.out.println(titulek);
        // doplnit
        for (int i = 0; i < a.length; i++) {
            if (i != 0) {
                System.out.print("\n");
            }
            for (int j = 0; j < a[0].length; j++) {

                System.out.print(a[i][j] + " ");
            }

        }
        System.out.print("\n");
    }

    /**
     * Vypíše matici a
     * 
     * @param a matice
     */
    private static void vypisMatice(double[][] a) {
        System.out.println("");
        // doplnit
        for (int i = 0; i < a.length; i++) {
            if (i != 0) {
                System.out.print("\n");
            }
            for (int j = 0; j < a[0].length; j++) {

                System.out.print(a[i][j] + " ");
            }

        }
        System.out.print("\n");
    }

    /**
     * Načte matici od uživatele (počet řádků, počet sloupců, prvky matice)
     *
     * @return načtená matice od uživatele
     */
    private static double[][] nacteniMatice() {

        System.out.println("Zadej pocet radku");
        int pr = sc.nextInt();
        System.out.println("Zadej pocet sloupcu");
        int ps = sc.nextInt();
        // doplnit dle
        double[][] a = new double[pr][ps];

        for (int i = 0; i < pr; i++) {
            for (int j = 0; j < ps; j++) {
                a[i][j] = sc.nextDouble();
            }
        }
        return a;
    }

    /**
     * Vymění matici A a matici B
     */
    private static void vymenaMatic() {

        // postaci vymenit reference
        if (jeNactena(matA) && jeNactena(matB)) {
            System.out.println("");
            System.out.println("Vzajemna vymena matic");
            double[][] temp = matA;
            matA = matB;
            matB = temp;
        } else {
            System.out.println("");
            System.out.println("Zkontrolujte správnost obou matic");
        }

    }

    /**
     * Vypíše soucet matic do konzole, pokud jsou správně zapsané a načtené pokud ne napíše chybnou hlášku
     */
    private static void soucetMaticVypis() {

        if (MatrixTools.soucetMatic(matA, matB) != null) {
            //System.out.println("");
            //System.out.println("Soucet matic");
            vypisMatice(MatrixTools.soucetMatic(matA, matB), "Soucet matic");
        } else {
            System.out.println("");
            System.out.println("Zkontrolujte správnost obou matic");
        }

    }

    /**
     * Vypíše součin matic do konzole, pokud jsou správně zapsané a načtené pokud ne napíše chybnou hlášku
     */
    private static void soucinMaticVypis() {

        if (MatrixTools.soucinMatic(matA, matB) != null) {
            //System.out.println("");
            //System.out.println("Soucin matic");
            vypisMatice(MatrixTools.soucinMatic(matA, matB), "Soucin matic");
        } else {
            System.out.println("");
            System.out.println("Zkontrolujte správnost obou matic");
        }
    }
    /**
     * Zjistí zda je matice a načtena nebo ne
     * @param a matice
     * @return Pokud je nečtena -> true, pokud ne -> false
     */
    private static boolean jeNactena(double[][] a) {
        if (a == null) {
            return false;
        }
        if (a.length == 0) {
            return false;
        }
        if (a[0].length == 0) {
            return false;
        } 
        return true;
    }
    /**
     * Převede matA do normovaného stavu
     */
    private static void prevedDoNormVypis() {
        if (jeNactena(matA)) {
            MatrixTools.prevedDoNorm(matA);
            vypisMatice(matA, "Matice A převedena do normovaného stavu");
        } else {
            System.out.println("");
            System.out.println("Matice A není načtena");
        }

    }
    /**
     * Vypisuje zda je matA stochatická
     */
    private static void jeStochatickaVypis() {
        
        if (jeNactena(matA) && MatrixTools.jeStochaticka(matA)) {
            System.out.println("");
            System.out.println("Matice A je stochatická");
        } else if (!jeNactena(matA)) {
            System.out.println("");
            System.out.println("Matice A není načtena");
        } else {
            System.out.println("");
            System.out.println("Matice A není stochatická");
        }
    }
}
